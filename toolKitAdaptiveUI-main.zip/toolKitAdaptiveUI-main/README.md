# toolKitAdaptiveUI

The files for the Adaptive Flutter Widgets to go with VLHCC 2021 paper

Luy, C., Law, J., Ho, L., Matheson, R., Cai, T., Madugalla, A., Grundy, J.C., A Toolkit for Building Adaptive User Interfaces for Vision-impaired Users, 2021 IEEE Symposium  on Visual Languages and Human-centric Computing (VLHCC2021), 10-13 October, St Louis, USA 

Author pre-print:  https://raw.githubusercontent.com/nzjohng/publications/master/papers/vlhcc2021.pdf

